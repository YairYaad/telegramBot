package org.example;

import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Panel extends JPanel implements ActionListener {

    EnterPanel enterPanel;
    StatisticPanel statisticPanel;
    HistoryPanel historyPanel;
    JButton subButton = new JButton("active bot");
    Bot bot;
    boolean flag;
//    int sumOfRequest = 0;
//    Id[] id = null;
//    String mostPopularRequest = "";

    Panel() {


        historyPanel = new HistoryPanel();
        historyPanel.setVisible(false);

        statisticPanel = new StatisticPanel();
        statisticPanel.setVisible(false);

        enterPanel = new EnterPanel();

        subButton.addActionListener(this);

        this.add(subButton);
        this.add(statisticPanel);
        this.add(historyPanel);
        this.add(enterPanel);
        this.setVisible(true);

        repaint();
    }

    public void paintComponent(Graphics graphics) {

        super.paintComponent(graphics);

        historyPanel.setBounds(230, 0, 300, 320);
        statisticPanel.setBounds(10, 0, 210, 130);
        if (flag) {

            historyPanel.setId(bot.getId());

            statisticPanel.setSumOfRequest(bot.getSumOfRequests());
            statisticPanel.setMostPopularRequest(bot.getMostPopularRequest());
            statisticPanel.setSumOfUsers(bot.getSumOfUsers());
            statisticPanel.setTheMostActiveUser(bot.getMostActiveUser());
        }

        enterPanel.setBounds(0, 0, 600, 600);
        subButton.setBounds(250, 500, 90, 30);

        repaint();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == subButton) {
            bot = new Bot(enterPanel.isOptional);
            flag = true;
            //id = bot.getId();
            //sumOfRequest = bot.getSumOfRequests();
            //mostPopularRequest = bot.getMostPopularRequest();
            //sumOfUsers = bot.getSumOfUsers();
            //mostActiveUser = bot.getMostActiveUser();
            TelegramBotsApi api = null;
            try {
                api = new TelegramBotsApi(DefaultBotSession.class);
                api.registerBot(bot);
            } catch (TelegramApiException ex) {
                throw new RuntimeException(ex);
            }

            for (int i = 0; i < enterPanel.isOptional.length; i++) {
                System.out.println(enterPanel.isOptional[i]);
            }
            enterPanel.setVisible(false);
            subButton.setVisible(false);
            statisticPanel.setVisible(true);
            historyPanel.setVisible(true);
            repaint();
        }
    }
}