package org.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.sql.Time;
import java.util.*;

public class Bot extends TelegramLongPollingBot {

    private ArrayList<Integer> sumPerDay;
    private Map<Long, Id> Users = new HashMap<>();
    private String[] option = {"random joke", "cat fact", "numbers fact", "random quote", "country"};
    private String massage = "Hi we have:";
    private boolean[] isAvailable;
    ArrayList<Id> idArrayList = new ArrayList<>();
    private int[] requestsCounter;
    private int sumOfRequests;
    private String mostActiveUser;

    public Bot(boolean[] isAvailable) {

        requestsCounter = new int[5];
        Arrays.fill(requestsCounter, 0);

        for (int i = 0; i < option.length; i++) {
            if (isAvailable[i]) {

                massage += "\n";
                massage += option[i];
            }
        }

        this.isAvailable = isAvailable;
    }

    @Override
    public String getBotUsername() {
        return "YYinformationbot";
    }

    @Override
    public String getBotToken() {
        return "5992274951:AAHVRg4t7JsZvGY3QLMpyLqghauMqv8O6C4";
    }

    @Override
    public void onUpdateReceived(Update update) {

        new Thread(() -> {

            long chatId = update.getMessage().getChatId();
            Id id = Users.get(chatId);
            SendMessage sendMessage = new SendMessage();
            sendMessage.setChatId(chatId);
            if (id == null) {
                id = new Id(update.getMessage().getChat().getUserName(), new Time(System.currentTimeMillis()), "Start");
                Users.put(chatId, id);
                sendMessage.setText(this.massage);
                idArrayList.add(id);
            } else {
                try {

                    id.setLestRequestsTime(new Time(System.currentTimeMillis()));
                    id.setSumOfRequests();

                    if (update.getMessage().getText().equals("random joke") && isAvailable[0]) { /////////////////////////////////////////////////////////////////////////////

                        sumOfRequests++;
                        requestsCounter[0]++;
                        id.setLestRequests("random joke");

                        HttpResponse<String> response = Unirest.get("https://official-joke-api.appspot.com/random_joke").asString();

                        ObjectMapper objectMapper = new ObjectMapper();
                        RandomJokeModel randomJokeModel = objectMapper.readValue(response.getBody(), RandomJokeModel.class);


                        sendMessage.setText(randomJokeModel.getSetup() + " " + randomJokeModel.getPunchline());
                    } else if (update.getMessage().getText().equals("cat fact") && isAvailable[1]) {///////////////////////////////////////////////////////////////////////////

                        sumOfRequests++;
                        requestsCounter[1]++;
                        id.setLestRequests("cat fact");

                        HttpResponse<String> response = Unirest.get("https://catfact.ninja/fact?max_length=140").asString();

                        ObjectMapper objectMapper = new ObjectMapper();
                        CatFactsModel catFactsModel = objectMapper.readValue(response.getBody(), CatFactsModel.class);

                        sendMessage.setText(catFactsModel.getFact());
                    } else if (update.getMessage().getText().equals("numbers fact") && isAvailable[2]) {///////////////////////////////////////////////////////////////////////

                        sumOfRequests++;
                        requestsCounter[2]++;
                        id.setLestRequests("numbers fact");

                        Random random = new Random();

                        int num = random.nextInt();

                        HttpResponse<String> response = Unirest.get("http://numbersapi.com/" + num + "/math?callback=showNumber").asString();

                        sendMessage.setText(response.getBody());
                    } else if (update.getMessage().getText().equals("random quote") && isAvailable[3]) {///////////////////////////////////////////////////////////////////////

                        sumOfRequests++;
                        requestsCounter[3]++;
                        id.setLestRequests("random quote");

                        HttpResponse<String> response = Unirest.get("https://api.quotable.io/random").asString();

                        ObjectMapper objectMapper = new ObjectMapper();
                        RandomQuoteFactModel randomQuoteFactModel = objectMapper.readValue(response.getBody(), RandomQuoteFactModel.class);

                        sendMessage.setText(randomQuoteFactModel.getContent() + "\n" + randomQuoteFactModel.getAuthor());
                    } else if (update.getMessage().getText().equals("country") && isAvailable[4]) {///////////////////////////////////////////////////////////////////////////

                        sumOfRequests++;
                        requestsCounter[4]++;

                        id.setLestRequests("country");

                        sendMessage.setText("Enter the alpha code");
//                    sendMessage.setText("Enter the alpha code");
//                    HttpResponse<String> response = Unirest.get("https://restcountries.com/v2/alpha/FRA").asString();
//
//                    ObjectMapper objectMapper = new ObjectMapper();
//                    CountryModel countryModel = objectMapper.readValue(response.getBody() , CountryModel.class);
                    } else if (id.getLestRequests().equals("country") && isAvailable[4]) {

                        String country = update.getMessage().getText();

                        HttpResponse<String> response = Unirest.get("https://restcountries.com/v2/alpha/" + country).asString();

                        ObjectMapper objectMapper = new ObjectMapper();
                        CountryModel countryModel = objectMapper.readValue(response.getBody(), CountryModel.class);

                        String border = "";
                        for (int i = 0; i < countryModel.getBorders().size(); i++) {
                            border += countryModel.getBorders().get(i) + ", ";
                        }
                        sendMessage.setText("name: " + countryModel.getName() + "\ncapital: " + countryModel.getCapital() + "\npopulation: " + countryModel.getPopulation() + "\nborder: " + border);
                    }/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

                } catch (Exception e) {
                    sendMessage.setText("something wrong");
                }
                //idArrayList.add(id);
            }
            try {
                execute(sendMessage);
            } catch (TelegramApiException e) {
                throw new RuntimeException(e);
            }
        }).start();
        System.out.println("user: " + Users.size());
        System.out.println("requests: " + sumOfRequests);
    }

    public Id[] getId() {

        Id[] ids = new Id[10];

        for (int i = 0; i < ids.length; i++) {
            if (idArrayList.size() - 1 >= i) {
                ids[i] = idArrayList.get(i);
            }else {
                ids[i] = null;
            }
        }

        return ids;
    }
    public int getSumOfRequests(){
        return sumOfRequests;
    }

    public String getMostPopularRequest(){

        int max = 0;
        String mostPopularRequest = "";

        for (int i = 0; i < requestsCounter.length; i++) {
            if (requestsCounter[i] > max){
                max = requestsCounter[i];
                mostPopularRequest = option[i];
            }
        }

        return mostPopularRequest;
    }

    public int getSumOfUsers(){
        return Users.size();
    }

    public String getMostActiveUser(){

        int max = 0;
        String mostActiveUser = "";

        for (int i = 0; i < idArrayList.size(); i++) {
            if (idArrayList.get(i).getSumOfRequests() > max){
                max = idArrayList.get(i).getSumOfRequests();
                mostActiveUser = idArrayList.get(i).getName();
            }
        }
        return mostActiveUser;
    }
}
