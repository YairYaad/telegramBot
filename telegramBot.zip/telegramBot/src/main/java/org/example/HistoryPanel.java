package org.example;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;
import java.sql.Time;

public class HistoryPanel extends JPanel{

    private Id[] id;

    HistoryPanel(){

        id = new Id[10];

        for (int i = 0; i < id.length; i++) {
            id[i] = new Id(" ", new Time(System.currentTimeMillis()), " ");
        }

        this.setBackground(Color.gray);
    }

    public void paintComponent(Graphics graphics){

        super.paintComponent(graphics);

        graphics.setFont(new Font(null, Font.PLAIN, 15));

//        String name = "nall";
//        String lestRequestTime = "nall";
//        String lestRequest = "nall";

        for (int i = 0; i < id.length; i++) {

            if (id[i] == null){
//                name = id[i].getName();
//                lestRequest = id[i].getLestRequests();
//                lestRequestTime = id[i].getLestRequestsTime().toString()
                graphics.drawString(i + 1 + "  name: nall, time: nall", 10, (i + 1) * 30);
                graphics.drawString( "    lastRequest: nall", 10, (i + 1) * 30 + 15);
            }else {
                graphics.drawString(i + 1 + "  name: " + id[i].getName() + ", time: " + id[i].getLestRequestsTime(), 10, (i + 1) * 30);
                graphics.drawString( "    lastRequest: " + id[i].getLestRequests(), 10, (i + 1) * 30 + 15);
            }
//            graphics.drawString(i + 1 + "  name: " + name + ", time: " +  lestRequestTime, 10, (i + 1) * 30);
//            graphics.drawString( "    lastRequest: " + lestRequest, 10, (i + 1) * 30 + 15);
        }
    }

    public Id[] getId() {
        return id;
    }

    public void setId(Id[] id) {
        this.id = id;
    }
}
